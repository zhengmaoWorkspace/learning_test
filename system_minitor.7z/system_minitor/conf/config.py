minitor_map = {
    "Local": {
        "items": ["cpu", "memory"],
        "trigger": [],
        "batch": 1
    }
}
