# coding: utf-8
import psutil

from conf import config


def processor(host):
    """
    返回当前主机的cpu信息，对cpu的每个核心计算使用率
    :return: map
    """
    result = {}
    batch = config.minitor_map.get(host).get("batch")
    # cpu核数
    # 默认逻辑cpu核数，False查看真实cpu核数；
    cpu_list = psutil.cpu_percent(batch, True)
    index = 1
    for core in cpu_list:
        core_name = "core-{}".format(index)
        result[core_name] = core
        index = index + 1
    return result
